import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='nitit',
    application_name='aws-flask-python',
    app_uid='wKCDH8V7dXr8HdZQ1y',
    org_uid='414c131a-9daf-493b-9893-59ea9760357d',
    deployment_uid='2c24eed4-b38c-4a4b-851e-2d137ae8a3d0',
    service_name='aws-python-flask-api-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-flask-api-project-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
